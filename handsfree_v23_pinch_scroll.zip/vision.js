import {FilesetResolver, FaceLandmarker, GestureRecognizer} from "./vendor/vision_bundle.mjs";

const video = document.getElementById("camera");
let stream, face, hands, active = true, lastTime = 0, busy = false;
const send = (type, extra = {}) => {
  window.parent.postMessage({channel: "HF_VISION_V22", type, ...extra}, "*");
};
window.addEventListener("pagehide", () => {
  active = false;
  if (stream) stream.getTracks().forEach(t => t.stop());
  try { face?.close(); } catch (_) {}
  try { hands?.close(); } catch (_) {}
});

async function start() {
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      audio: false, video: {width: {ideal: 640}, height: {ideal: 480}, facingMode: "user"}
    });
    video.srcObject = stream;
    await video.play();
    const wasm = await FilesetResolver.forVisionTasks(chrome.runtime.getURL("vendor/wasm"));
    face = await FaceLandmarker.createFromOptions(wasm, {
      baseOptions: {modelAssetPath: chrome.runtime.getURL("models/face_landmarker.task"), delegate: "CPU"},
      runningMode: "VIDEO", numFaces: 1
    });
    hands = await GestureRecognizer.createFromOptions(wasm, {
      baseOptions: {modelAssetPath: chrome.runtime.getURL("models/gesture_recognizer.task"), delegate: "CPU"},
      runningMode: "VIDEO", numHands: 1
    });
    send("ready");
    requestAnimationFrame(loop);
  } catch (error) {
    console.error("Vision startup failed", error);
    send("error", {message: String(error?.message || error)});
  }
}
function loop() {
  if (!active) return;
  const now = performance.now();
  if (!busy && video.readyState >= 2 && now - lastTime > 50) {
    busy = true;
    lastTime = now;
    try {
      const timestamp = now;
      const f = face.detectForVideo(video, timestamp);
      const h = hands.recognizeForVideo(video, timestamp);
      const nose = f.faceLandmarks?.[0]?.[1];
      const points = h.landmarks?.[0];
      const fingertip = points?.[8];
      const thumbtip = points?.[4];
      const middleTip = points?.[12];
      const middlePip = points?.[10];
      const indexPip = points?.[6];
      const wrist = points?.[0];
      // Normalize pinch threshold against hand size for distance independence.
      const handSize = points && wrist ? Math.hypot(points[5].x - wrist.x, points[5].y - wrist.y) : 0;
      const pinch = Boolean(fingertip && thumbtip && handSize > 0.035 &&
        Math.hypot(fingertip.x-thumbtip.x,fingertip.y-thumbtip.y) < handSize * 0.37);
      const scroll = Boolean(fingertip && middleTip && indexPip && middlePip &&
        fingertip.y < indexPip.y - 0.025 &&
        middleTip.y < middlePip.y - 0.025 && !pinch);
      send("landmarks", {
        nose: nose ? {x:nose.x,y:nose.y} : null,
        hand: fingertip ? {x:fingertip.x,y:fingertip.y} : null,
        pinch, scroll
      });
    } catch (error) {
      console.error("Vision inference failed", error);
      send("error", {message: String(error?.message || error)});
      return;
    } finally { busy = false; }
  }
  requestAnimationFrame(loop);
}
start();
