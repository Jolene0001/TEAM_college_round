chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id || !/^https?:/.test(tab.url || "")) return;
  try { await chrome.tabs.sendMessage(tab.id, {action:"LAUNCH_SYSTEM"}); }
  catch (error) { console.warn("Cannot reach tab; refresh the page and try again.", error); }
});
