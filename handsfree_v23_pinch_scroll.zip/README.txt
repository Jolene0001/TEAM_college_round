Hands-Free Web Navigator v23

CHANGES:
- Removed dwell-to-click completely: looking at a target will NOT click it.
- Pinch index finger and thumb together once to click the control under the purple pointer.
  Release before pinching again. 800ms cooldown.
- Hold index and middle fingers extended, and move the hand vertically to scroll.
- Voice commands 'scroll up' and 'scroll down' now run before dictation handling and
  attempt to scroll the nearest scrollable container (useful on modern websites).
- Existing start/stop dictation remains unchanged.
- Camera inference remains inside the extension-owned vision frame.

INSTALL:
1. Extract the ZIP.
2. Disable the previous version at chrome://extensions.
3. Load unpacked from the new folder, refresh your website and start the tracker.

TESTING:
JavaScript syntax checked; not yet tested in a real Chrome webcam session.
Some site-specific errors may remain; send screenshots from chrome://extensions > Errors
if the extension still reports errors. Third-party page errors are not necessarily extension errors.
