Hands-Free Web Navigator v26

NEW VOICE COMMANDS:
- 'pause', 'pause video', 'pause audio', 'pause media'
- 'play', 'play video', 'play audio', 'resume'
- 'volume up', 'increase volume', 'louder'
- 'volume down', 'decrease volume', 'quieter'
- 'mute', 'unmute'

Volume changes in 10 percentage-point increments, clamped to 0%-100%.
The commands control an HTML5 video/audio element in the current webpage.
They do NOT change your computer's master volume. Embedded cross-origin
players, DRM, custom players, and browser pages may not respond.
Playback may be blocked until the user interacts with the page.

All v25 features remain: persistent activation, voice deactivation, clear
text, face cursor, pinch single-click, victory double-click, thumbs scrolling,
voice navigation, dictation.

INSTALL: Disable the older version in chrome://extensions; extract this ZIP;
Load unpacked from the extracted folder; refresh your site.
Syntax checked, not tested in a live Chrome session.
