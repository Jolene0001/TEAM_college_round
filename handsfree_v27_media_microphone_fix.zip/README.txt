Hands-Free Web Navigator v27.0

Changes:
- Speech recognition now runs in an extension-origin iframe (voice.html), not
  in the website content script. This aims to reuse the extension-origin mic
  permission across navigations. A first grant may still be required.
- Voice media commands run through chrome.scripting.executeScript in the MAIN
  world to control the page's HTML5 audio/video element.
- Supports pause, play, volume up/down (10%), mute/unmute.
- All existing gesture, dictation, voice navigation and persistence preserved.

Limitations: Embedded cross-origin media frames, DRM and site-specific custom
players may not respond. Some Chrome policies may still prompt for microphone
when an extension-origin iframe is recreated; truly uninterrupted voice across
navigations requires a persistent extension document.

Installation: Disable previous version, extract ZIP, Load unpacked, refresh.
Syntax checked, not live browser tested.
