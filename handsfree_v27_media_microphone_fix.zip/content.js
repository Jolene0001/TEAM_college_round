;(function () {
  if (window.hfCleanup) {
    try {
      window.hfCleanup();
    } catch (err) {}
  }

  var oldOverlay = document.getElementById("hfActivationOverlay");
  if (oldOverlay) oldOverlay.remove();

  var oldWidget = document.getElementById("hfWidgetContainer");
  if (oldWidget) oldWidget.remove();

  var oldPointer = document.getElementById("handsFreePointerGlobal");
  if (oldPointer) oldPointer.remove();

  window.hfPointerEl = null;
  window.hfLastKnownX = 0;
  window.hfLastKnownY = 0;

  var trackingActive = false;
  var localStream = null;
  var recognition = null;
  var isSpeechEngineRunning = false;
  var startingRecognition = false;
  var restartTimer = null;
  var heartbeatTimer = null;
  var disposed = false;
  var dictationActive = false;
  var dictationField = null;
  var fieldHighlight = null;
  var elementFilterMode = "important";

  function cleanup() {
    disposed = true;
    trackingActive = false;

    if (restartTimer !== null) {
      clearTimeout(restartTimer);
      restartTimer = null;
    }

    if (heartbeatTimer !== null) {
      clearInterval(heartbeatTimer);
      heartbeatTimer = null;
    }

    if (recognition) {
      recognition.onstart = null;
      recognition.onresult = null;
      recognition.onerror = null;
      recognition.onend = null;

      try {
        recognition.abort();
      } catch (err) {}

      recognition = null;
    }

    isSpeechEngineRunning = false;
    startingRecognition = false;

    if (localStream) {
      localStream.getTracks().forEach(function (track) {
        track.stop();
      });
      localStream = null;
    }

    ["hfActivationOverlay", "hfWidgetContainer", "handsFreePointerGlobal", "hfVoiceFrame"].forEach(function (id) {
      var element = document.getElementById(id);
      if (element) element.remove();
    });

    window.hfPointerEl = null;
    dictationActive = false;
    dictationField = null;
    clearFieldHighlight();

    if (
      typeof chrome !== "undefined" &&
      chrome.runtime &&
      chrome.runtime.onMessage
    ) {
      try {
        chrome.runtime.onMessage.removeListener(messageListener);
      } catch (err) {}
    }
  }

  window.hfCleanup = cleanup;

  function messageListener(request) {
    if (request && request.action === "LAUNCH_SYSTEM") {
      // Clicking the toolbar icon can also reactivate a stopped session.
      chrome.storage.local.set({hfEnabled:true}, function () {
        if (disposed) return;
        var overlay = document.getElementById("hfActivationOverlay");
        if (overlay) overlay.remove();
        initializeAllInOneSystem();
      });
    }
  }

  if (
    typeof chrome !== "undefined" &&
    chrome.runtime &&
    chrome.runtime.onMessage
  ) {
    try {
      chrome.runtime.onMessage.addListener(messageListener);
    } catch (err) {
      console.warn("Extension messaging unavailable:", err.message);
    }
  }

  function injectActivationOverlay() {
    if (
      disposed ||
      document.getElementById("hfActivationOverlay") ||
      document.getElementById("hfWidgetContainer")
    ) {
      return;
    }

    var overlay = document.createElement("div");
    overlay.id = "hfActivationOverlay";

    Object.assign(overlay.style, {
      position: "fixed",
      top: "15px",
      left: "50%",
      transform: "translateX(-50%)",
      backgroundColor: "#ffffff",
      border: "4px solid #9c27b0",
      borderRadius: "30px",
      padding: "12px 28px",
      boxShadow: "0 8px 24px rgba(0,0,0,0.2)",
      zIndex: "2147483646",
      display: "flex",
      alignItems: "center",
      gap: "15px",
      fontFamily: "Arial, sans-serif"
    });

    var txt = document.createElement("span");
    txt.innerText = "🤖 Hands-Free Access Ready!";

    Object.assign(txt.style, {
      color: "#202124",
      fontWeight: "bold",
      fontSize: "14px"
    });

    var btn = document.createElement("button");
    btn.innerText = "Initialize Accessibility Framework";

    Object.assign(btn.style, {
      backgroundColor: "#9c27b0",
      color: "#ffffff",
      border: "none",
      padding: "8px 18px",
      borderRadius: "20px",
      cursor: "pointer",
      fontWeight: "bold",
      fontSize: "13px"
    });

    btn.addEventListener("click", function () {
      overlay.remove();
      chrome.storage.local.set({hfEnabled:true});
      initializeAllInOneSystem();
    });

    overlay.appendChild(txt);
    overlay.appendChild(btn);
    document.body.appendChild(overlay);
  }

  async function initializeAllInOneSystem() {
    if (disposed || document.getElementById("hfWidgetContainer")) {
      return;
    }

    if (
      !navigator.mediaDevices ||
      !navigator.mediaDevices.getUserMedia
    ) {
      alert("Camera and microphone access is unavailable on this page. Try a regular HTTPS website.");
      injectActivationOverlay();
      return;
    }

    var container = document.createElement("div");
    container.id = "hfWidgetContainer";

    Object.assign(container.style, {
      position: "fixed",
      bottom: "20px",
      right: "20px",
      width: "180px",
      height: "170px",
      backgroundColor: "#202124",
      border: "4px solid #9c27b0",
      borderRadius: "14px",
      boxShadow: "0 10px 30px rgba(0,0,0,0.3)",
      zIndex: "2147483645",
      overflow: "hidden",
      fontFamily: "Arial, sans-serif"
    });

    var header = document.createElement("div");
    header.innerText = "📹 HANDS-FREE TRACKER ACTIVE";

    Object.assign(header.style, {
      color: "#ffffff",
      backgroundColor: "#9c27b0",
      fontSize: "9px",
      fontWeight: "bold",
      textAlign: "center",
      padding: "5px 0"
    });

    var visionFrame = document.createElement("iframe");
    visionFrame.id = "hfVisionFrame";
    visionFrame.src = chrome.runtime.getURL("vision.html");
    visionFrame.setAttribute("allow", "camera");
    Object.assign(visionFrame.style, {
      width: "100%", height: "110px", border: "0", display: "block"
    });

    var statusBanner = document.createElement("div");
    statusBanner.id = "hfStatusBanner";
    statusBanner.innerText = "🎙️ Initializing...";

    Object.assign(statusBanner.style, {
      color: "#34a853",
      backgroundColor: "#ffffff",
      fontSize: "9px",
      fontWeight: "bold",
      textAlign: "center",
      padding: "4px 0"
    });

    container.appendChild(header);
    container.appendChild(visionFrame);
    container.appendChild(statusBanner);
    document.body.appendChild(container);
    // Speech runs on the extension origin instead of each website origin.
    var voiceFrame = document.createElement("iframe");
    voiceFrame.id = "hfVoiceFrame";
    voiceFrame.src = chrome.runtime.getURL("voice.html");
    voiceFrame.setAttribute("allow", "microphone");
    Object.assign(voiceFrame.style, {position:"fixed", width:"1px", height:"1px", opacity:"0", pointerEvents:"none", border:"0"});
    document.documentElement.appendChild(voiceFrame);

    // Receive only landmark coordinates from the extension-owned vision page.
    // No webcam frames or speech data are sent to the website.
    var neutralNose = null;
    var smoothedX = null;
    var smoothedY = null;
    var lastGestureClickAt = 0;
    var victoryFrames = 0;
    var victoryReleaseFrames = 0;
    var victoryArmed = true;
    var lastDoubleClickAt = 0;
    var pinchFrames = 0;
    var pinchArmed = true;
    var pinchReleaseFrames = 0;
    var scrollDirection = 0;
    var scrollCandidate = 0;
    var scrollCandidateFrames = 0;
    var scrollLastMessageAt = 0;
    var scrollTimer = setInterval(function () {
      if (disposed || !trackingActive || !scrollDirection ||
          performance.now() - scrollLastMessageAt > 260) return;
      scrollNearest(scrollDirection * 12);
    }, 40);
    var lastTrackedAt = 0;

    function pointerTarget() {
      var hit = document.elementFromPoint(window.hfLastKnownX + 19, window.hfLastKnownY + 19);
      return hit && hit.closest(
        'a[href],button,input:not([type="hidden"]),select,textarea,' +
        '[role="button"],[role="link"],[role="checkbox"],[role="tab"],[tabindex]:not([tabindex="-1"])'
      );
    }

    function gestureClick() {
      var target = pointerTarget();
      if (!target || !target.isConnected || target.disabled ||
          target.getAttribute("aria-disabled") === "true" ||
          target.closest("#hfWidgetContainer, #hfActivationOverlay, #hfFieldNavigationPanel")) return;
      // Protect sensitive payment/password controls from accidental activation.
      if (target.matches('input[type="password"],input[autocomplete^="cc-"]')) return;
      try {
        target.focus({preventScroll:true});
        target.click();
        setStatus("✋ Pinch selected: " + (target.getAttribute("aria-label") || target.innerText || target.tagName).trim().slice(0,45));
        window.hfPointerEl.style.backgroundColor = "#00e676";
        setTimeout(function () {
          if (window.hfPointerEl) window.hfPointerEl.style.backgroundColor = "rgba(156, 39, 176, 0.9)";
        }, 250);
      } catch (err) { console.warn("Gesture click failed", err); }
    }

    function gestureDoubleClick() {
      var target = pointerTarget();
      if (!target || !target.isConnected || target.disabled ||
          target.getAttribute("aria-disabled") === "true" ||
          target.closest("#hfWidgetContainer, #hfActivationOverlay, #hfFieldNavigationPanel") ||
          target.matches('input[type="password"],input[autocomplete^="cc-"]')) return;
      try {
        target.focus({preventScroll:true});
        target.click();
        target.click();
        target.dispatchEvent(new MouseEvent("dblclick", {
          bubbles:true, cancelable:true, composed:true, detail:2,
          clientX:window.hfLastKnownX+19, clientY:window.hfLastKnownY+19
        }));
        setStatus("✌️ Double click");
      } catch (err) { console.warn("Double click failed:",err); }
    }

    function scrollNearest(amount) {
      var el = document.elementFromPoint(
        Math.min(window.innerWidth - 1, Math.max(0, window.hfLastKnownX + 19)),
        Math.min(window.innerHeight - 1, Math.max(0, window.hfLastKnownY + 19))
      );
      var scroller = el;
      while (scroller && scroller !== document.body && scroller !== document.documentElement) {
        var st = getComputedStyle(scroller);
        if (/(auto|scroll|overlay)/.test(st.overflowY) &&
            scroller.scrollHeight > scroller.clientHeight + 10) {
          scroller.scrollBy({top:amount,behavior:"auto"});
          return;
        }
        scroller = scroller.parentElement;
      }
      window.scrollBy({top:amount,behavior:"auto"});
    }

    var trackingMessageHandler = function(event) {
      if (disposed || event.origin !== new URL(chrome.runtime.getURL("vision.html")).origin ||
          event.source !== visionFrame.contentWindow || !event.data ||
          event.data.channel !== "HF_VISION_V22") return;
      var data = event.data;
      if (data.type === "ready") {
        trackingActive = true;
        statusBanner.innerText = "Face cursor · pinch click · victory double-click";
        statusBanner.style.color = "#188038";
        // Voice recognition starts in the extension-origin voice frame.
        // It can receive a single extension-origin microphone grant.
        return;
      }
      if (data.type === "error") {
        trackingActive = false;
        statusBanner.innerText = "Vision error: " + String(data.message).slice(0, 80);
        statusBanner.style.color = "#b00020";
        console.error("Vision iframe error:", data.message);
        return;
      }
      if (data.type !== "landmarks") return;
      var now = performance.now();
      var x = null, y = null;
      // Face is the ONLY cursor controller; gestures never move it.
      if (data.nose && Number.isFinite(data.nose.x) && Number.isFinite(data.nose.y)) {
        if (!neutralNose) neutralNose = {x:data.nose.x,y:data.nose.y};
        x = window.innerWidth / 2 + (neutralNose.x - data.nose.x) * window.innerWidth * 2;
        y = window.innerHeight / 2 + (data.nose.y - neutralNose.y) * window.innerHeight * 2;
      }
      if (x !== null && y !== null) {
        lastTrackedAt = now;
        x = Math.max(0, Math.min(window.innerWidth - 38, x - 19));
        y = Math.max(0, Math.min(window.innerHeight - 38, y - 19));
        smoothedX = smoothedX === null ? x : smoothedX + (x - smoothedX) * 0.28;
        smoothedY = smoothedY === null ? y : smoothedY + (y - smoothedY) * 0.28;
        updateLivePointer(Math.round(smoothedX), Math.round(smoothedY));
      }
      // Debounced pinch: hold for at least 3 consecutive frames (~150ms),
      // then release for 3 frames to re-arm. Never click while scrolling.
      var pinch = data.pinch === true;
      var requestedScroll = data.scrollDirection === 1 || data.scrollDirection === -1
        ? data.scrollDirection : 0;
      if (pinch && !requestedScroll && data.victory !== true) {
        pinchFrames++;
        pinchReleaseFrames = 0;
      } else {
        pinchFrames = 0;
        pinchReleaseFrames++;
        if (pinchReleaseFrames >= 3) pinchArmed = true;
      }
      if (pinchArmed && pinchFrames >= 3 && now - lastGestureClickAt > 850 &&
          now - lastTrackedAt < 350) {
        lastGestureClickAt = now;
        pinchArmed = false;
        gestureClick();
      }
      // Hold a V/peace sign for 5 frames to double-click. Release to re-arm.
      var victory = data.victory === true && !pinch && !requestedScroll;
      if (victory) {
        victoryFrames++;
        victoryReleaseFrames = 0;
      } else {
        victoryFrames = 0;
        victoryReleaseFrames++;
        if (victoryReleaseFrames >= 4) victoryArmed = true;
      }
      if (victoryArmed && victoryFrames >= 5 &&
          now - lastDoubleClickAt > 1100 && now - lastTrackedAt < 350) {
        lastDoubleClickAt = now;
        victoryArmed = false;
        gestureDoubleClick();
      }
      // Require 3 consistent frames before changing scroll direction.
      // Scroll at a fixed speed while the gesture remains visible.
      if (requestedScroll === scrollCandidate) scrollCandidateFrames++;
      else { scrollCandidate = requestedScroll; scrollCandidateFrames = 1; }
      if (scrollCandidateFrames >= 3) scrollDirection = requestedScroll;
      if (requestedScroll) scrollLastMessageAt = now;
      if (!requestedScroll && scrollCandidateFrames >= 2) scrollDirection = 0;

    };
    window.addEventListener("message", trackingMessageHandler);
    var voiceMessageHandler = function (event) {
      if (disposed || event.origin !== new URL(chrome.runtime.getURL("voice.html")).origin ||
          event.source !== voiceFrame.contentWindow || !event.data ||
          event.data.channel !== "HF_VOICE_V27") return;
      if (event.data.type === "command" && typeof event.data.text === "string")
        handleVoiceCommand(event.data.text);
      else if (event.data.type === "status") setStatus(event.data.text);
    };
    window.addEventListener("message", voiceMessageHandler);
    var originalCleanup = window.hfCleanup;
    window.hfCleanup = function () {
      window.removeEventListener("message", trackingMessageHandler);
      window.removeEventListener("message", voiceMessageHandler);
      clearInterval(scrollTimer);
      originalCleanup();
    };

  }

  function updateLivePointer(x, y) {
    if (disposed) return;

    if (!window.hfPointerEl) {
      window.hfPointerEl = document.createElement("div");
      window.hfPointerEl.id = "handsFreePointerGlobal";

      Object.assign(window.hfPointerEl.style, {
        position: "fixed",
        width: "30px",
        height: "30px",
        backgroundColor: "rgba(156, 39, 176, 0.9)",
        border: "4px solid white",
        borderRadius: "50%",
        zIndex: "2147483647",
        pointerEvents: "none",
        boxShadow: "0 0 15px rgba(0,0,0,0.4)",
        transition: "left 0.02s linear, top 0.02s linear"
      });

      document.body.appendChild(window.hfPointerEl);
    }

    window.hfLastKnownX = Math.max(
      0,
      Math.min(x, window.innerWidth - 38)
    );

    window.hfLastKnownY = Math.max(
      0,
      Math.min(y, window.innerHeight - 38)
    );

    window.hfPointerEl.style.left =
      window.hfLastKnownX + "px";

    window.hfPointerEl.style.top =
      window.hfLastKnownY + "px";
  }

  function getFieldLabel(el) {
    if (!el) return "";
    var labels = [];

    if (el.labels) {
      Array.from(el.labels).forEach(function (label) {
        labels.push(label.innerText || "");
      });
    }

    [
      el.getAttribute("aria-label"),
      el.getAttribute("placeholder"),
      el.getAttribute("name"),
      el.getAttribute("id"),
      el.getAttribute("autocomplete"),
      el.getAttribute("title")
    ].forEach(function (value) {
      if (value) labels.push(value);
    });

    var labelledBy = el.getAttribute("aria-labelledby");
    if (labelledBy) {
      labelledBy.split(/\s+/).forEach(function (id) {
        var label = document.getElementById(id);
        if (label) labels.push(label.innerText || label.textContent || "");
      });
    }

    return labels.join(" ").toLowerCase();
  }

  function isSensitiveField(el) {
    if (!el) return true;

    var type = (el.type || "").toLowerCase();
    var autocomplete = (el.getAttribute("autocomplete") || "").toLowerCase();
    var label = getFieldLabel(el);

    if ([
      "password", "hidden", "file", "checkbox", "radio",
      "button", "submit", "reset", "image"
    ].includes(type)) return true;

    if (/^(cc-|current-password|new-password|one-time-code)/.test(autocomplete)) {
      return true;
    }

    return /\b(password|passcode|one[- ]time code|verification code|security code|cvv|cvc|credit card|debit card|card number|cardholder|card holder|expiration date|expiry date|card expiry|iban|bank account|routing number)\b/i.test(label);
  }

  function isEditableField(el) {
    if (!el || !el.isConnected || isSensitiveField(el)) return false;
    if (el.disabled || el.readOnly || el.getAttribute("aria-disabled") === "true") return false;
    if (el.closest("#hfWidgetContainer, #hfActivationOverlay, #hfFieldNavigationPanel")) return false;
    if (el.closest("[inert]")) return false;

    var tag = el.tagName;
    var type = (el.type || "").toLowerCase();
    var supportedInputTypes = ["", "text", "search", "email", "tel", "url", "number"];

    if (tag === "INPUT" && !supportedInputTypes.includes(type)) return false;
    if (tag !== "INPUT" && tag !== "TEXTAREA" &&
        !el.isContentEditable && el.getAttribute("role") !== "textbox") return false;

    var style = window.getComputedStyle(el);
    var rect = el.getBoundingClientRect();

    return style.display !== "none" &&
      style.visibility !== "hidden" &&
      rect.width > 0 && rect.height > 0;
  }

  function isNavigableElement(el) {
    if (!el || !el.isConnected) return false;
    if (el.closest("#hfWidgetContainer, #hfActivationOverlay, #hfFieldNavigationPanel")) return false;
    if (el.closest("[inert]")) return false;
    if (el.disabled || el.getAttribute("aria-disabled") === "true") return false;
    if (el.getAttribute("aria-hidden") === "true") return false;

    var tag = el.tagName;
    var naturallyFocusable = /^(A|BUTTON|INPUT|SELECT|TEXTAREA|SUMMARY)$/.test(tag);
    var hasTabIndex = el.hasAttribute("tabindex") && Number(el.getAttribute("tabindex")) >= 0;
    var editable = el.isContentEditable || el.getAttribute("role") === "textbox";
    var interactiveRole = /^(button|link|checkbox|radio|switch|tab|menuitem|option|combobox|slider)$/.test(
      (el.getAttribute("role") || "").toLowerCase()
    );

    if (!naturallyFocusable && !hasTabIndex && !editable && !interactiveRole) return false;
    if (tag === "A" && !el.hasAttribute("href") && !hasTabIndex) return false;
    if (tag === "INPUT" && (el.type || "").toLowerCase() === "hidden") return false;
    if (isSensitiveField(el)) return false;

    var style = window.getComputedStyle(el);
    var rect = el.getBoundingClientRect();
    if (style.display === "none" || style.visibility === "hidden" ||
        style.visibility === "collapse" || rect.width <= 0 || rect.height <= 0) return false;

    return true;
  }

  function getElementSearchText(el) {
    var parts = [
      getFieldLabel(el),
      el.innerText,
      el.textContent,
      el.getAttribute("aria-label"),
      el.getAttribute("title"),
      el.getAttribute("name"),
      el.getAttribute("placeholder"),
      el.getAttribute("type"),
      el.getAttribute("role"),
      el.getAttribute("href"),
      el.getAttribute("aria-haspopup")
    ];

    return parts.filter(Boolean).join(" ").toLowerCase()
      .replace(/https?:\/\/|www\./g, " ")
      .replace(/[^\w\s-]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function isImportantElement(el) {
    var text = getElementSearchText(el);
    var type = (el.type || "").toLowerCase();
    var role = (el.getAttribute("role") || "").toLowerCase();
    var tag = el.tagName;

    // Text-entry fields are useful for hands-free tasks, but sensitive fields stay excluded.
    if (isEditableField(el)) {
      if (type === "search" || /\b(search|find|look up|query)\b/.test(text)) return true;
      if (/\b(sign in|log in|login|register|sign up|create account|email|username|your name|full name|first name|last name|address|phone)\b/.test(text)) return true;
      // Keep ordinary visible text fields so users can still reach forms with unlabeled inputs.
      if (tag === "TEXTAREA" || el.isContentEditable) return true;
      if (["text", "email", "tel", "url"].includes(type)) return true;
    }

    var importantTerms = /\b(search|find|sign in|log in|login|sign up|register|account|profile|my account|continue|submit|checkout|check out|buy now|add to cart|cart|basket|place order|order now|purchase|pay now|payment|book now|subscribe|confirm|save|send|apply|next|back|menu|navigation|home|shop|products|categories|play|pause|download|upload|settings|help|contact|support|watch|listen|join|start free trial|free trial|view cart|go to cart|proceed)\b/;
    if (importantTerms.test(text)) return true;

    // Preserve common high-value controls even if their visible label is short.
    if (tag === "INPUT" && type === "submit") return true;
    if (role === "search" || role === "searchbox") return true;

    // Search/account/cart links are frequently icon-only; inspect their URL too.
    var href = (el.getAttribute("href") || "").toLowerCase();
    if (/\b(search|signin|sign-in|login|log-in|account|profile|cart|checkout|basket|purchase|order|menu)\b/.test(href)) return true;

    return false;
  }

  function getNavigableElements() {
    var selector = [
      "a[href]", "button", "input:not([type='hidden'])", "select", "textarea",
      "summary", "[tabindex]", "[contenteditable='true']",
      "[role='button']", "[role='link']", "[role='checkbox']",
      "[role='radio']", "[role='switch']", "[role='tab']",
      "[role='menuitem']", "[role='option']", "[role='combobox']",
      "[role='slider']", "[role='textbox']", "[role='search']", "[role='searchbox']"
    ].join(",");

    var seen = new Set();
    return Array.from(document.querySelectorAll(selector))
      .filter(function (el) {
        if (seen.has(el)) return false;
        seen.add(el);
        if (!isNavigableElement(el)) return false;
        return elementFilterMode === "all" || isImportantElement(el);
      })
      .sort(function (a, b) {
        var aTab = a.hasAttribute("tabindex") ? Number(a.getAttribute("tabindex")) : 0;
        var bTab = b.hasAttribute("tabindex") ? Number(b.getAttribute("tabindex")) : 0;
        var aPositive = aTab > 0;
        var bPositive = bTab > 0;
        if (aPositive && bPositive && aTab !== bTab) return aTab - bTab;
        if (aPositive !== bPositive) return aPositive ? -1 : 1;
        var position = a.compareDocumentPosition(b);
        if (position & Node.DOCUMENT_POSITION_FOLLOWING) return -1;
        if (position & Node.DOCUMENT_POSITION_PRECEDING) return 1;
        return 0;
      });
  }

  function setElementFilterMode(mode) {
    elementFilterMode = mode === "all" ? "all" : "important";
    setStatus(elementFilterMode === "all"
      ? "🔎 All-elements navigation enabled"
      : "⭐ Important-elements navigation enabled");
  }

  function focusNextElement(direction) {
    var elements = getNavigableElements();
    if (!elements.length) {
      setStatus("⚠️ No interactive elements found");
      return false;
    }

    var current = document.activeElement;
    var index = elements.indexOf(current);
    var nextIndex = index === -1
      ? (direction > 0 ? 0 : elements.length - 1)
      : (index + direction + elements.length) % elements.length;

    var el = elements[nextIndex];
    dictationActive = false;
    dictationField = null;

    try {
      el.focus({ preventScroll: true });
    } catch (err) {
      el.focus();
    }

    try {
      el.scrollIntoView({ block: "center", behavior: "smooth" });
    } catch (err) {}

    highlightField(el);

    var label = getFieldLabel(el);
    if (!label) {
      label = (el.innerText || el.textContent || el.getAttribute("aria-label") || el.tagName || "")
        .trim().replace(/\s+/g, " ").slice(0, 55);
    }
    if (!label) label = el.tagName.toLowerCase();

    setStatus("🎯 Element " + (nextIndex + 1) + " of " + elements.length + ": " + label);
    return true;
  }

  function activateFocusedElement() {
    var el = document.activeElement;
    if (!isNavigableElement(el)) {
      setStatus("⚠️ Say “Next element” to select a control first");
      return false;
    }

    if (isEditableField(el)) {
      el.focus();
      startDictation();
      return true;
    }

    if (el.tagName === "INPUT" && ["checkbox", "radio"].includes((el.type || "").toLowerCase())) {
      el.click();
    } else if (el.tagName === "SELECT") {
      el.focus();
      setStatus("🔽 Dropdown focused — use the page's available selection controls");
      return true;
    } else {
      el.click();
    }

    setStatus("✅ Activated selected element");
    return true;
  }

  function getEditableFields() {
    var selector = [
      "input:not([type='hidden'])",
      "textarea",
      "[contenteditable='true']",
      "[role='textbox']"
    ].join(",");

    return Array.from(document.querySelectorAll(selector)).filter(isEditableField);
  }

  function clearFieldHighlight() {
    if (fieldHighlight && fieldHighlight.isConnected) {
      fieldHighlight.style.outline = fieldHighlight.dataset.hfPreviousOutline || "";
      fieldHighlight.style.outlineOffset = fieldHighlight.dataset.hfPreviousOutlineOffset || "";
      delete fieldHighlight.dataset.hfPreviousOutline;
      delete fieldHighlight.dataset.hfPreviousOutlineOffset;
    }
    fieldHighlight = null;
  }

  function highlightField(el) {
    clearFieldHighlight();
    if (!el) return;

    fieldHighlight = el;
    el.dataset.hfPreviousOutline = el.style.outline || "";
    el.dataset.hfPreviousOutlineOffset = el.style.outlineOffset || "";
    el.style.outline = "3px solid #1687ff";
    el.style.outlineOffset = "2px";
  }

  function focusNextField(direction) {
    var fields = getEditableFields();
    if (!fields.length) {
      setStatus("⚠️ No supported text fields found");
      return false;
    }

    var current = document.activeElement;
    var index = fields.indexOf(current);
    var nextIndex;

    if (index === -1) {
      nextIndex = direction > 0 ? 0 : fields.length - 1;
    } else {
      nextIndex = (index + direction + fields.length) % fields.length;
    }

    var field = fields[nextIndex];
    field.focus();
    try {
      field.scrollIntoView({ block: "center", behavior: "smooth" });
    } catch (err) {}

    highlightField(field);
    setStatus("📝 Field " + (nextIndex + 1) + " of " + fields.length + " selected");
    return true;
  }

  function startDictation() {
    var field = document.activeElement;

    if (!isEditableField(field)) {
      var fields = getEditableFields();
      if (!fields.length) {
        setStatus("⚠️ No safe text field found");
        return false;
      }
      field = fields[0];
      field.focus();
    }

    dictationField = field;
    dictationActive = true;
    highlightField(field);
    setStatus("🎤 Dictation ON — speak, or say “stop dictation”");
    return true;
  }

  function stopDictation() {
    dictationActive = false;
    dictationField = null;
    setStatus("🎙️ Dictation OFF — listening for navigation commands");
  }

  function insertDictatedText(text) {
    var el = dictationField;

    if (!el || !el.isConnected || !isEditableField(el)) {
      stopDictation();
      setStatus("⚠️ Selected field is no longer available");
      return false;
    }

    el.focus();

    if (el.isContentEditable) {
      var inserted = false;
      try {
        inserted = document.execCommand("insertText", false, text);
      } catch (err) {}
      if (!inserted) {
        setStatus("⚠️ This editor does not support direct dictation");
        return false;
      }
      return true;
    }

    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      var prototype = el.tagName === "TEXTAREA"
        ? window.HTMLTextAreaElement.prototype
        : window.HTMLInputElement.prototype;
      var descriptor = Object.getOwnPropertyDescriptor(prototype, "value");
      var setter = descriptor && descriptor.set;

      if (!setter) return false;

      var start = typeof el.selectionStart === "number" ? el.selectionStart : el.value.length;
      var end = typeof el.selectionEnd === "number" ? el.selectionEnd : start;
      var currentValue = el.value;
      setter.call(el, currentValue.slice(0, start) + text + currentValue.slice(end));

      var cursor = start + text.length;
      try {
        el.setSelectionRange(cursor, cursor);
      } catch (err) {}

      el.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    }

    if (el.getAttribute("role") === "textbox") {
      setStatus("⚠️ This custom text field may not support dictation");
      return false;
    }

    return false;
  }

  function clearSelectedText() {
    var el = dictationActive && isEditableField(dictationField)
      ? dictationField : document.activeElement;
    if (!isEditableField(el)) {
      setStatus("⚠️ Focus a text field before saying clear text");
      return;
    }
    el.focus();
    if (el.isContentEditable) {
      var selection = window.getSelection();
      var range = document.createRange();
      range.selectNodeContents(el);
      selection.removeAllRanges();
      selection.addRange(range);
      if (!document.execCommand("delete", false)) {
        el.textContent = "";
        el.dispatchEvent(new InputEvent("input", {bubbles:true, inputType:"deleteContentBackward"}));
      }
    } else if (el.tagName === "INPUT" || el.tagName === "TEXTAREA") {
      var proto = el.tagName === "TEXTAREA"
        ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      var setter = Object.getOwnPropertyDescriptor(proto,"value").set;
      setter.call(el,"");
      el.dispatchEvent(new Event("input",{bubbles:true,composed:true}));
      el.dispatchEvent(new Event("change",{bubbles:true}));
    } else {
      setStatus("⚠️ This editor does not support clearing");
      return;
    }
    setStatus("🧹 Text cleared");
  }

  function deactivateSystem() {
    // Stop immediately; persist the disabled state for future page loads.
    window.hfCleanup();
    chrome.storage.local.set({hfEnabled:false});
  }

  function handleMediaCommand(command) {
    var aliases = {
      "pause":"pause", "pause video":"pause", "pause audio":"pause", "pause media":"pause", "stop playback":"pause",
      "play":"play", "play video":"play", "play audio":"play", "play media":"play", "resume":"play", "resume video":"play", "resume playback":"play",
      "volume up":"up", "increase volume":"up", "raise volume":"up", "louder":"up",
      "volume down":"down", "decrease volume":"down", "lower volume":"down", "quieter":"down",
      "mute":"mute", "mute audio":"mute", "mute video":"mute", "unmute":"unmute", "unmute audio":"unmute", "unmute video":"unmute"
    };
    var action = aliases[command];
    if (!action) return false;
    // A background-script injection runs in the page MAIN world. This can
    // control native media even when the site wraps it in a custom player.
    chrome.runtime.sendMessage({action:"HF_MEDIA", mediaAction:action}, function (response) {
      if (disposed) return;
      if (chrome.runtime.lastError || !response || !response.ok) {
        setStatus("⚠️ " + (response && response.error || "Media player not accessible"));
      } else {
        setStatus(response.message);
      }
    });
    return true;
  }

  function handleVoiceCommand(rawTranscript) {
    var transcript = (rawTranscript || "").trim();
    var command = transcript.toLowerCase().replace(/[.!?]+$/g, "").trim();

    if (!command) return;

    // Playback commands are recognized even while dictation is active.
    if (handleMediaCommand(command)) return;

    if (/^(deactivate|deactivate accessibility|stop accessibility|turn off accessibility|turn off navigator|stop hands free|stop hands-free|disable hands free|disable hands-free)$/.test(command)) {
      deactivateSystem();
      return;
    }

    if (/^(clear text|clear field|clear input|erase text|delete all text|clear all)$/.test(command)) {
      clearSelectedText();
      return;
    }

    if (/^(stop dictation|finish dictation|end dictation|cancel dictation)$/.test(command)) {
      stopDictation();
      return;
    }

    if (/^(start dictation|begin dictation|dictation mode)$/.test(command)) {
      startDictation();
      return;
    }

    if (/^(important elements|important mode|filter important|priority mode)$/.test(command)) {
      setElementFilterMode("important");
      return;
    }

    if (/^(all elements|show all elements|all controls|all mode|unfiltered mode)$/.test(command)) {
      setElementFilterMode("all");
      return;
    }

    if (/^(next element|next button|next control|tab next|tab)$/.test(command)) {
      focusNextElement(1);
      return;
    }

    if (/^(previous element|previous button|previous control|shift tab|back tab)$/.test(command)) {
      focusNextElement(-1);
      return;
    }

    if (/^(activate|activate selected|click selected|press enter)$/.test(command)) {
      activateFocusedElement();
      return;
    }

    if (/^(next field|next text field|next input)$/.test(command)) {
      dictationActive = false;
      dictationField = null;
      focusNextField(1);
      return;
    }

    if (/^(previous field|prior field|previous text field|previous input)$/.test(command)) {
      dictationActive = false;
      dictationField = null;
      focusNextField(-1);
      return;
    }

    if (/^(scroll )?(down|up)( please)?$/.test(command)) {
      scrollNearest(command.includes("down") ? 540 : -540);
      setStatus(command.includes("down") ? "⬇️ Scrolled down" : "⬆️ Scrolled up");
      return;
    }

    if (dictationActive) {
      if (insertDictatedText(transcript)) {
        setStatus("✍️ Added dictated text");
      }
      return;
    }

    if (/^(yes|okay|ok|click)$/.test(command)) {
      if (!window.hfPointerEl) return;

      var targetEl = document.elementFromPoint(
        window.hfLastKnownX + 15,
        window.hfLastKnownY + 15
      );

      if (!targetEl ||
          targetEl.closest("#hfWidgetContainer") ||
          targetEl.closest("#hfActivationOverlay")) return;

      targetEl.click();

      if (targetEl.matches("input, textarea, [contenteditable='true'], [role='textbox']")) {
        targetEl.focus();
        if (isEditableField(targetEl)) highlightField(targetEl);
      }

      window.hfPointerEl.style.backgroundColor = "#00e676";
      setTimeout(function () {
        if (window.hfPointerEl) {
          window.hfPointerEl.style.backgroundColor = "rgba(156, 39, 176, 0.9)";
        }
      }, 400);
    }
  }

  function setStatus(message) {
    var banner = document.getElementById("hfStatusBanner");

    if (banner && !banner.innerText.startsWith("Vision error:")) {
      banner.innerText = message;
    }
  }

  document.addEventListener("focusin", function (event) {
    if (isNavigableElement(event.target)) {
      highlightField(event.target);
      if (dictationActive && isEditableField(event.target)) {
        dictationField = event.target;
      }
    }
  }, true);

  document.addEventListener("pointerdown", function (event) {
    var target = event.target && event.target.closest
      ? event.target.closest("input, textarea, [contenteditable='true'], [role='textbox']")
      : null;

    if (target && isEditableField(target)) {
      highlightField(target);
      if (dictationActive) dictationField = target;
    }
  }, true);

  heartbeatTimer = setInterval(function () {
    if (disposed) return;

    document.querySelectorAll('a[target="_blank"]').forEach(function (link) {
      link.setAttribute("target", "_self");
    });

    restartVoiceSafely();
  }, 1000);

  function restoreSession() {
    chrome.storage.local.get({hfEnabled:false}, function (state) {
      if (disposed || !document.body) return;
      if (state.hfEnabled) initializeAllInOneSystem();
      else injectActivationOverlay();
    });
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", restoreSession, {once:true});
  } else {
    restoreSession();
  }
})();
