(() => {
  "use strict";
  const Speech = window.SpeechRecognition || window.webkitSpeechRecognition;
  const channel = "HF_VOICE_V27";
  const send = (type, data) => parent.postMessage({channel, type, ...data}, "*");
  if (!Speech) { send("status", {text:"⚠️ Speech recognition unsupported"}); return; }
  let recognition, active = false, retry = null, stopped = false;
  const begin = () => {
    if (stopped || active) return;
    try { recognition.start(); } catch (_) { schedule(); }
  };
  const schedule = () => {
    if (stopped || retry !== null) return;
    retry = setTimeout(() => { retry = null; begin(); }, 1400);
  };
  recognition = new Speech();
  recognition.lang = "en-US";
  recognition.continuous = true;
  recognition.interimResults = false;
  recognition.onstart = () => { active = true; send("status", {text:"🎙️ Listening for commands and dictation"}); };
  recognition.onresult = (event) => {
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const result = event.results[i];
      if (result.isFinal && result[0]) send("command", {text:result[0].transcript});
    }
  };
  recognition.onerror = (event) => {
    active = false;
    if (event.error === "not-allowed" || event.error === "service-not-allowed") {
      stopped = true;
      send("status", {text:"⚠️ Allow microphone for the extension to enable voice"});
      return;
    }
    if (event.error === "audio-capture") {
      stopped = true;
      send("status", {text:"⚠️ Microphone unavailable"});
      return;
    }
    schedule();
  };
  recognition.onend = () => { active = false; schedule(); };
  window.addEventListener("pagehide", () => {
    stopped = true;
    if (retry !== null) clearTimeout(retry);
    try { recognition.abort(); } catch (_) {}
  });
  begin();
})();