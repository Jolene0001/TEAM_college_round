chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id || !/^https?:/.test(tab.url || "")) return;
  try { await chrome.tabs.sendMessage(tab.id, {action:"LAUNCH_SYSTEM"}); }
  catch (error) { console.warn("Cannot reach tab; refresh the page and try again.", error); }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (!request || request.action !== "HF_MEDIA") return false;
  const action = request.mediaAction;
  if (!["pause","play","up","down","mute","unmute"].includes(action) || !sender.tab?.id) {
    sendResponse({ok:false,error:"Invalid media command"}); return false;
  }
  chrome.scripting.executeScript({
    target:{tabId:sender.tab.id, frameIds:[sender.frameId ?? 0]},
    world:"MAIN",
    func: async (action) => {
      const candidates = Array.from(document.querySelectorAll("video,audio"));
      const valid = candidates.filter(el => el.isConnected);
      const media = valid.find(el => !el.paused && !el.ended) ||
        valid.find(el => { const r=el.getBoundingClientRect(); return r.width>30 && r.height>30; }) || valid[0];
      if (!media) return {ok:false,error:"No accessible media player found"};
      try {
        if (action === "pause") { media.pause(); return {ok:true,message:"⏸️ Media paused"}; }
        if (action === "play") { await media.play(); return {ok:true,message:"▶️ Media playing"}; }
        if (action === "mute") { media.muted=true; return {ok:true,message:"🔇 Media muted"}; }
        if (action === "unmute") { media.muted=false; return {ok:true,message:"🔊 Media unmuted"}; }
        media.muted=false;
        media.volume=Math.max(0,Math.min(1,Math.round((media.volume+(action==="up"?.1:-.1))*10)/10));
        return {ok:true,message:"🔊 Volume " + Math.round(media.volume*100) + "%"};
      } catch (e) { return {ok:false,error:String(e.message||e)}; }
    },
    args:[action]
  }).then(results => sendResponse(results?.[0]?.result || {ok:false,error:"No player result"}))
    .catch(e => sendResponse({ok:false,error:e.message}));
  return true;
});