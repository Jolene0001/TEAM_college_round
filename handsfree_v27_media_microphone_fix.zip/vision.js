import {FilesetResolver, FaceLandmarker, GestureRecognizer} from "./vendor/vision_bundle.mjs";

const video = document.getElementById("camera");
let stream, face, hands, active = true, lastTime = 0, busy = false;
const send = (type, extra = {}) => {
  window.parent.postMessage({channel: "HF_VISION_V22", type, ...extra}, "*");
};
window.addEventListener("pagehide", () => {
  active = false;
  if (stream) stream.getTracks().forEach(t => t.stop());
  try { face?.close(); } catch (_) {}
  try { hands?.close(); } catch (_) {}
});

async function start() {
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      audio: false, video: {width: {ideal: 640}, height: {ideal: 480}, facingMode: "user"}
    });
    video.srcObject = stream;
    await video.play();
    const wasm = await FilesetResolver.forVisionTasks(chrome.runtime.getURL("vendor/wasm"));
    face = await FaceLandmarker.createFromOptions(wasm, {
      baseOptions: {modelAssetPath: chrome.runtime.getURL("models/face_landmarker.task"), delegate: "CPU"},
      runningMode: "VIDEO", numFaces: 1
    });
    hands = await GestureRecognizer.createFromOptions(wasm, {
      baseOptions: {modelAssetPath: chrome.runtime.getURL("models/gesture_recognizer.task"), delegate: "CPU"},
      runningMode: "VIDEO", numHands: 1
    });
    send("ready");
    requestAnimationFrame(loop);
  } catch (error) {
    console.error("Vision startup failed", error);
    send("error", {message: String(error?.message || error)});
  }
}
function loop() {
  if (!active) return;
  const now = performance.now();
  if (!busy && video.readyState >= 2 && now - lastTime > 50) {
    busy = true;
    lastTime = now;
    try {
      const timestamp = now;
      const f = face.detectForVideo(video, timestamp);
      const h = hands.recognizeForVideo(video, timestamp);
      const nose = f.faceLandmarks?.[0]?.[1];
      const points = h.landmarks?.[0];
      const fingertip = points?.[8];
      const thumbtip = points?.[4];
      const wrist = points?.[0];
      const indexMcp = points?.[5];
      const thumbMcp = points?.[2];
      const thumbIp = points?.[3];
      const middleTip = points?.[12];
      const ringTip = points?.[16];
      const pinkyTip = points?.[20];
      const indexPip = points?.[6];
      const middlePip = points?.[10];
      const ringPip = points?.[14];
      const pinkyPip = points?.[18];
      const handSize = points && wrist ? Math.hypot(indexMcp.x-wrist.x,indexMcp.y-wrist.y) : 0;
      const pinch = Boolean(fingertip && thumbtip && handSize > 0.035 &&
        Math.hypot(fingertip.x-thumbtip.x,fingertip.y-thumbtip.y) < handSize * 0.31);
      // Use MediaPipe's recognized gestures to avoid thumb-angle ambiguity.
      // A thumbs-up/down must be held with other fingers curled.
      const categories = h.gestures?.[0] || [];
      const best = categories[0];
      let scrollDirection = 0;
      if (!pinch && best && best.score >= 0.67) {
        if (best.categoryName === "Thumb_Up") scrollDirection = -1;
        else if (best.categoryName === "Thumb_Down") scrollDirection = 1;
      }
      const victory = Boolean(!pinch && best && best.categoryName === "Victory" &&
        best.score >= 0.68);
      send("landmarks", {
        nose: nose ? {x:nose.x,y:nose.y} : null,
        pinch, scrollDirection, victory
      });
    } catch (error) {
      console.error("Vision inference failed", error);
      send("error", {message: String(error?.message || error)});
      return;
    } finally { busy = false; }
  }
  requestAnimationFrame(loop);
}
start();
