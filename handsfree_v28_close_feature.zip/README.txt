Hands-Free Web Navigator v27.0

Changes:
- Speech recognition now runs in an extension-origin iframe (voice.html), not
  in the website content script. This aims to reuse the extension-origin mic
  permission across navigations. A first grant may still be required.
- Voice media commands run through chrome.scripting.executeScript in the MAIN
  world to control the page's HTML5 audio/video element.
- Supports pause, play, volume up/down (10%), mute/unmute.
- All existing gesture, dictation, voice navigation and persistence preserved.

Limitations: Embedded cross-origin media frames, DRM and site-specific custom
players may not respond. Some Chrome policies may still prompt for microphone
when an extension-origin iframe is recreated; truly uninterrupted voice across
navigations requires a persistent extension document.

Installation: Disable previous version, extract ZIP, Load unpacked, refresh.
Syntax checked, not live browser tested.

v28 NEW: Say "close handsfree", "close hands free", "exit handsfree" or
"deactivate accessibility" to close the widget and stop tracking and
listening. Or click the × button in the tracker header. Closing persists
across future pages. Reactivate by clicking the extension toolbar icon
or the activation button after reloading a page.

Chrome microphone/camera permissions are managed by Chrome and cannot
be revoked by the extension. Closing stops active capture and recognition.

Syntax-checked; not tested with live camera/microphone.
